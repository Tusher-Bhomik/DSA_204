import java.io.*;
import java.util.Objects;

public class Main {
    private static final String INPUT_FILE_NAME = "input.txt";
    public static void main(String[] args) throws IOException {
        PrintStream ps = new PrintStream("list_output.txt");
        System.setOut(ps);

        BS_Tree tree =new BS_Tree();//create a empty tree
        Node root=tree.getRoot();
        BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE_NAME));
        while(true)
        {
            String line = br.readLine();
            if (line == null) break;
            String[] out = line.split(" ");
            switch (out[0]) {

                case "I" -> {
                    root = tree.insert(root, Integer.parseInt(out[1]));
                    tree.setRoot(root);
                    System.out.println(tree);
                }
                case "D" -> {
                    root = tree.delete(root, Integer.parseInt(out[1]));
                    if(tree.getFlag())//true means not found
                    {
                        System.out.println("Invalid Operation");
                        //tree.setFlag(false);
                        continue;
                    }
                    tree.setRoot(root);
                    System.out.println(tree);
                }
                case "F" -> {
                    if(tree.search(root, Integer.parseInt(out[1])))
                    {
                        System.out.println("True");
                    }
                    else {
                        System.out.println("False");
                    }
                    tree.setRoot(root);
                }
                case "T"->
                {
                    if(Objects.equals(out[1], "In"))
                    {
                        tree.inOrder(root);
                        System.out.println();

                    }
                    else if(Objects.equals(out[1], "Pre"))
                    {
                        tree.preOrder(root);
                        System.out.println();
                    }
                    else {
                        tree.postOrder(root);
                        System.out.println();
                    }
                }
            }
        }

    }
}