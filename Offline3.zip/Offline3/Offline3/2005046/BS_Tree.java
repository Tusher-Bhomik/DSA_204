public class BS_Tree {
    private String str;
    private boolean flag=false;
    private Node root;
    public Node getRoot() {
        return root;
    }
    public void setRoot(Node temp)
    {
        this.root=temp;
    }
    public Node  createNewNode(int data)
    {
        return new Node(data);
    }
    BS_Tree()
    {
        root=null;
    }
    public Node insert(Node root, int data)
    {

        if(root==null)
        {
            root=createNewNode(data);
        }
        else if(data<=root.getData())
        {
            root.setLeft(insert(root.getLeft(),data));
        }
        else {
            root.setRight(insert(root.getRight(),data));
        }
        return root;
    }
    public boolean search(Node root,int data)
    {
        if(root==null)return false;
        else if(root.getData()==data) return true;
        else if(data<=root.getData())return search(root.getLeft(),data);
        else{
            return search(root.getRight(),data);
        }
    }
    public Node delete(Node root,int data)
    {
        if(root==null) {
            flag=true;
            return null;
        }
        else if(data<root.getData())
            root.setLeft(delete(root.getLeft(),data));
        else if(data>root.getData())
            root.setRight(delete(root.getRight(),data));
        else {//root found ,now check whether leaf or not
            if(root.getLeft()==null&& root.getRight()==null) {
                root = null;
                flag=false;
            }
            else
            {
                flag=true;
            }

//             if i want to delete any node
//            else if(root.getLeft()==null)
//            {
//                Node temp=root;
//                root=root.getRight();
//                temp=null;
//            }
//            else if(root.getRight()==null)
//            {
//                Node temp=root;
//                root=root.getLeft();
//                temp=null;
//            }
//            else
//            {//3rd case--> i will find minimum element
//                //in case of right i will find minimum
//                //else i wil find maximum
//
//                Node temp=min(root.getRight());
//                root.setData(temp.getData());
//                root.setRight(delete(root.getRight(), temp.getData()));
//
//            }
        }
        return root;
    }
    //needed if i want to delete any node
    public Node min(Node root)
    {
        while (root.getLeft()!=null)
            root=root.getLeft();
        return root;
    }
    public void inOrder(Node root)
    {
        if(root==null)return;
        inOrder(root.getLeft());
        System.out.print(root.getData()+" ");
        inOrder(root.getRight());
    }
    public void preOrder(Node root)
    {
        if(root==null)return;
        System.out.print(root.getData()+" ");
        preOrder(root.getLeft());
        preOrder(root.getRight());
    }
    public void postOrder(Node root)
    {
        if(root==null)return;
        postOrder(root.getLeft());
        postOrder(root.getRight());
        System.out.print(root.getData()+" ");
    }
    public void stringGenerator(Node root)
    {
        if(root == this.root)str="";
        if(root==null)
            return ;

        if(root.getRight()==null && root.getLeft()==null)
            str+=root.getData();
        else
        {
            str+=root.getData()+"(";
            stringGenerator(root.getLeft());
            str+=")(";
            stringGenerator(root.getRight());
            str+=")";
        }
    }
    public String toString()
    {
        stringGenerator(root);
        return str;
    }

    public boolean getFlag() {
        return flag;
    }

    public void setFlag(Boolean flag) {
        this.flag = flag;
    }
}
