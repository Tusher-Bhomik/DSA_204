public class QueueLL <T>{

    private Node<T> head;
    private Node<T> tail;
    private int length;
    QueueLL(int x)
    {
        tail=head=new Node<>();
    }
    public void clear()
    {
        length=0;
    }

    public void enqueue(T item)
    {
        if(length==0)
        {
            tail=head=new Node<>();
            head.setData(item);
            head.setNext(null);
        }
        else {
            Node<T> newNode = new Node<>();
            newNode.setData(item);
            newNode.setNext(null);
            tail.setNext(newNode);
            tail = newNode;
        }
        length++;
    }
    public T dequeue()
    {
        if(length==0)return null;//check when length ==1
        else {
            T ret=head.getData();
            head=head.getNext();
            length--;
            return ret;
        }
    }
    public int length()
    {
        return length;
    }
    public T frontValue()
    {
        if(length==0)return null;
        return head.getData();
    }
    public T rearValue()
    {
        if(length==0)return null;
        return tail.getData();
    }
    public T leaveQueue()
    {
        if(length==0) {
            head=tail=null;
            return null;
        }
        else if(length==1)
        {
            T ret= head.getData();
            length--;
            head=tail=null;
            return ret;
        }
        else
        {
            Node<T> temp=new Node<>();
            T ret= tail.getData();
            temp=head;
            int i=1;
            while(i<length-1)
            {
                temp=temp.getNext();
                i++;
            }
            tail=temp;
            tail.setNext(null);
            length--;
            return ret;
        }

    }
    public String toString()
    {
        Node<T> temp=new Node<>();
        temp = head;
        String str=new String();
        if (length== 0) str+="<>";
        else {
            str += "< ";
            while (temp != null) {
                if(temp==head) str+=("|");
                str += temp.getData() + " ";
                temp = temp.getNext();
            }
            str += ">";
        }
        return str;
    }

}
