public class StackLL <T>{
    private Node<T> top;
    private Node<T> tail;
    private int length;
    StackLL(int x)
    {
        tail=top=new Node<>();
    }
    public void clear()
    {
        length=0;
    }
    public void push(T item)
    {
        if(length==0)
        {
            tail=top=new Node<>();
            top.setData(item);
            top.setNext(null);
        }
        else {
            Node<T> newNode = new Node<>();
            newNode.setData(item);
            newNode.setNext(null);
            tail.setNext(newNode);
            tail = newNode;
        }
        length++;

    }
    public T pop()
    {
            if(length==0)
            {
                top=tail=null;
                return null;
            }
            else if(length==1)
            {
                T ret= top.getData();
                top=tail=null;
                length--;
                return ret;
            }
            else
            {
                Node<T>temp=new Node<>();
                T ret= tail.getData();
                temp=top;
                int i=1;
                while(i<length-1)
                {
                    temp=temp.getNext();
                    i++;
                }
                tail=temp;
                tail.setNext(null);
                length--;
                return ret;
            }
    }
    public int length()
    {
        return length;
    }
    public T topValue()
    {
        return tail.getData();
    }
    public String toString()
    {
        Node<T> temp=new Node<>();
        temp = top;
        String str=new String();
        if (length== 0) str+="<>";

        else {
            int i=0;
            str += "< ";
            while (i<length) {
                if(i==length-1) str+=("|");
                str += temp.getData() + " ";
                temp = temp.getNext();
                i++;
            }
            str += ">";
        }
        return str;
    }
}
