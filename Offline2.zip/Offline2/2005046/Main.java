import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        PrintStream ps = new PrintStream("list_output.txt");
        InputStream is = new FileInputStream("input.txt");

        System.setIn(is);
        System.setOut(ps);
        int K1,X1;
        Scanner scanner=new Scanner(System.in);
        K1=scanner.nextInt();
        X1=scanner.nextInt();
        QueueLL<String>queue=new QueueLL<>(X1);
        for(int i=0;i<K1;i++)
        {
            queue.enqueue(scanner.next());
        }
        int K2,X2;
        K2=scanner.nextInt();
        X2=scanner.nextInt();
        StackLL<String>stack=new StackLL<>(X2);
        for(int i=0;i<K2;i++)
        {
            stack.push(scanner.next());
        }

        int Q=scanner.nextInt();
        int i=0;
        System.out.println(queue);
        System.out.println(stack);
        while(i<Q)
        {
            int F=scanner.nextInt();//which function wil run
            switch (F) {
                case 1 -> {
                    String p = scanner.next();
                    queue.clear();
                    System.out.println(queue);
                    System.out.println(-1);
                }
                case 2 -> {
                    String P = scanner.next();
                    queue.enqueue(P);
                    System.out.println(queue);
                    System.out.println(-1);
                }
                case 3 -> {
                    String a = scanner.next();
                    String ret=queue.dequeue();
                    System.out.println(queue);
                    if(ret==null)
                    {
                        System.out.println(-1);
                    }
                    else
                    {
                        System.out.println(ret);
                    }
                }
                case 4 -> {
                    String b = scanner.next();
                    int len = queue.length();
                    System.out.println(queue);
                    System.out.println(len);
                }
                case 5 -> {
                    String c = scanner.next();
                    String f = queue.frontValue();
                    System.out.println(queue);
                    if(f==null)
                    {
                        System.out.println(-1);
                    }
                    else
                    {
                        System.out.println(f);
                    }
                }
                case 6 -> {
                    String d = scanner.next();
                    String g = queue.rearValue();
                    System.out.println(queue);
                    if(g==null)
                    {
                        System.out.println(-1);
                    }
                    else
                    {
                        System.out.println(g);
                    }
                }
                case 7 -> {
                    String e = scanner.next();
                    String h = queue.leaveQueue();
                    System.out.println(queue);
                    if(h==null)
                    {
                        System.out.println(-1);
                    }
                    else
                    {
                        System.out.println(h);
                    }
                }
                case 8 -> {
                    String P=scanner.next();
                    stack.clear();
                    System.out.println(stack);
                    System.out.println(-1);
                }
                case 9 -> {
                    String P=scanner.next();
                    stack.push(P);
                    System.out.println(stack);
                    System.out.println(-1);
                }
                case 10 ->{
                    String P=scanner.next();
                    String ret= stack.pop();
                    System.out.println(stack);
                    if(ret==null)
                    {
                        System.out.println(-1);
                    }
                    else
                    {
                        System.out.println(ret);
                    }
                }
                case 11 ->{
                    String P=scanner.next();
                    int len=stack.length();
                    System.out.println(stack);
                    System.out.println(len);
                }
                case 12 ->{
                    String P=scanner.next();
                    String ret=stack.topValue();
                    System.out.println(stack);
                    if(ret==null)
                    {
                        System.out.println(-1);
                    }
                    else
                    {
                        System.out.println(ret);
                    }
                }
            }
            i++;
        }
    }
}