public class StackArr<T> {
    private int initCapacity;
    private int length;
    private int currentCapacity;
    private T[]arr;
    public StackArr(int X)
    {
        initCapacity=X;
        currentCapacity=X;
        this.arr= (T[]) new Object[X];
    }
    public void clear()
    {
        length=0;
    }
    public void push(T item)
    {
        //check length=0?
        if(length==0)
        {
            arr= (T[]) new Object[initCapacity];
            currentCapacity=initCapacity;
        }
        //check length=?initCapacity
        if(length==currentCapacity)
        {
            extendArray();
        }
        arr[length++]=item;
    }
    public T pop()
    {//check whether stack is empty or not
        if(length==0)return null;
        T ret=arr[length-1];
        length--;
        return ret;
    }
    public int length()
    {
        return length;
    }
    public T topValue()
    {
        if(length==0)return null;
        return arr[length-1];
    }
    private void extendArray()
    {
        T[] arr2= (T[]) new Object[currentCapacity*2];
        for(int i=0;i<length;i++)
        {
            arr2[i]=arr[i];
        }
        this.arr=arr2;
        currentCapacity=currentCapacity*2;
    }
    public String toString() {
        StringBuilder str2= new StringBuilder(new String());
        if (length== 0) str2.append("<>");
        else {
            str2.append("< ");
            for (int i = 0; i < length; i++) {
                if(i==length-1) str2.append("|");
                str2.append(arr[i]).append(" ");
            }
            str2.append(">");
        }
        return str2.toString();
    }



}
