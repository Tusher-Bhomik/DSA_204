public class QueueArr <T>{
    private int initCapacity;
    private int currentCapacity;
    private int length;
    private T[]arr;
    public QueueArr(int X) {
        initCapacity=X;
        currentCapacity=X;
        this.arr= (T[]) new Object[X];
    }
    public void clear()
    {
        length=0;
    }
    public void enqueue(T item)
    {
        //ekta o element nai,queue full(need to extend size )
        if(length==0)
        {
            arr= (T[]) new Object[initCapacity];
            currentCapacity=initCapacity;
        }
        if(length==currentCapacity)
        {
            extendArray();
        }
        arr[length++]=item;
    }
    public T dequeue()//jei type er value niye
    {
        T item;
        if(length==0)
        {
            return null;//array length zero hole ekhanei return kore dibe
        }
        item=arr[0];
        for(int i=1;i<length;i++)
        {
            arr[i-1]=arr[i];
        }
        length--;
        // if(length==initCapacity/2)
        return item;
    }
    public int length()
    {
        return  length;
    }
    public T frontValue()
    {//check whether queue is empty or not
        if(length==0)return null;
        return arr[0];
    }
    public T rearValue()
    {//check whether list is empty or not
        if(length==0)return null;
        return arr[length-1];
    }
    public T leaveQueue()
    {//check whether queue is empty or not
        if(length==0)return null;
        T ob=arr[length-1];
        length--;
        return ob;
    }
    @Override
    public String toString() {
        StringBuilder str= new StringBuilder(new String());
        if (length== 0) str.append("<>");
        else {
            str.append("< ");
            for (int i = 0; i < length; i++) {
                if(i==0) str.append("|");
                str.append(arr[i]).append(" ");
            }
            str.append(">");
        }
        return str.toString();
    }
    private void extendArray()
    {
        T[] arr2= (T[]) new Object[currentCapacity*2];
        for(int i=0;i<length;i++)
        {
            arr2[i]=arr[i];
        }
        this.arr=arr2;
        currentCapacity=currentCapacity*2;
    }

}
