


        Node class->> for linkedList implementation of stack and queue

        QueueArr--->> Queue implementation by array
        StackArr---->> Stack implementation by array

        QueueLL----->>Queue implementation by LinkedList
        StackLL---->>  stack implementation by LinkedList

        Main--->> for implementing task one
        Store2---->> for implementing task two