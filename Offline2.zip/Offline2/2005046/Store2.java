import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;
class Gamer2 {
    private int id;
    private int startTime;
    private int exitTime;
    public int getExitTime() {
        return exitTime;
    }
    public void setExitTime(int exitTime) {
        this.exitTime = exitTime;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getStartTime() {
        return startTime;
    }
    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }
    public int getDuration() {
        return duration;
    }
    public void setDuration(int duration) {
        this.duration = duration;
    }
    private int duration;
    public Gamer2(int id, int startTime, int duration) {
        this.id = id;
        this.startTime = startTime;
        this.duration = duration;
    }
}

public class Store2 {
    public static void main(String[] args) throws FileNotFoundException {
        PrintStream ps = new PrintStream("list_output.txt");
        InputStream is = new FileInputStream("input.txt");

        System.setIn(is);
        System.setOut(ps);
        int n, time;
        Scanner scanner = new Scanner(System.in);
        n = scanner.nextInt();
        time = scanner.nextInt();
        Gamer2[] allGamers = new Gamer2[n];
        int start, duration;
        for (int i = 0; i < n; i++) {
            start = scanner.nextInt();
            duration = scanner.nextInt();
            allGamers[i] = new Gamer2(i, start, duration);
        }

        int currentTime = 0;
        int gamerTracker = -1;
        boolean found = false, console1 = true, console2 = true;//true means not occupied
        int console1willFree = 0, console2willFree = 0;

        QueueArr<Gamer2> gQueue = new QueueArr<>(3);
        StackLL<Gamer2> gStack = new StackLL<>(3);


        while (currentTime <= time) {
            //pop from stack or Queue

            if (currentTime == console1willFree) {//for console 1
                if (gQueue.length() > 0) {
                    Gamer2 temp = gQueue.dequeue();
                    allGamers[temp.getId()].setExitTime(currentTime + allGamers[temp.getId()].getDuration());
                    console1willFree = allGamers[temp.getId()].getExitTime();
                } else {
                    console1 = true;
                }
            }//duplicate will not work
            if (currentTime == console2willFree) {//for console 2
                for (int i = 0; i < n; i++) {//enter and pop simultaneously
                    if (currentTime == allGamers[i].getStartTime()) {
                        found = true;
                        gamerTracker = i;
                    }
                }
                if(found)// if anyone enters and duration is zero
                {
                    console2willFree = currentTime + allGamers[gamerTracker].getDuration();
                    allGamers[gamerTracker].setExitTime(console2willFree);
                    console2=false;
                    found=false;
                    currentTime++;
                    continue;

                }
                if (gStack.length() > 0) {
                    Gamer2 temp = gStack.pop();

                    allGamers[temp.getId()].setExitTime(currentTime + allGamers[temp.getId()].getDuration());
                    console2willFree = allGamers[temp.getId()].getExitTime();
                } else {
                    console2 = true;
                }
            }

            //push in stack or queue
            for (int i = 0; i < n; i++) {
                if (currentTime == allGamers[i].getStartTime()) {
                    found = true;
                    gamerTracker = i;
                }
            }
            if(found) {
                if (console1)//if console1 is empty
                {
                    console1 = false;  //console1 occupied( false means occupied)
                    console1willFree = currentTime + allGamers[gamerTracker].getDuration();
                    allGamers[gamerTracker].setExitTime(console1willFree);
                }
                else//console 1 fill up ,so try for queue of console1
                {
                    if (gQueue.length() < 3)//if console 1's queue's length is less than 3 push here
                    {
                        gQueue.enqueue(allGamers[gamerTracker]);
                    }
                    else {
                        //console 1 empty ,console 1's queue is full,so check  whether console 2 is empty or not
                        if (console2) {

                            console2willFree = currentTime + allGamers[gamerTracker].getDuration();
                            allGamers[gamerTracker].setExitTime(console2willFree);
                            console2=false;
                        } else {//if not push here
                            gStack.push(allGamers[gamerTracker]);
                        }
                    }
                }
            }
            currentTime++;
            found=false;
        }
        for (int i = 0; i < n; i++) {
            if(allGamers[i].getExitTime()>time)
                System.out.println(i+1+">"+time);
            else
            {
                System.out.println(i+1+">"+allGamers[i].getExitTime());
            }
        }
    }
}

