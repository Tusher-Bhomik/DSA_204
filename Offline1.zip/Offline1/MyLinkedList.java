public class MyLinkedList<T> {
    private Node<T> head;
    private Node<T> tail;
    private Node<T> currentNode;
    private int currentSize;
    MyLinkedList()
    {
        head=new Node<>();
        currentNode=tail=head;
    }//time complexity- O(1)
    MyLinkedList(int X)
    {
        head=new Node<>();
        tail=head;
        currentNode=head;
    }//time complexity- O(1)

    MyLinkedList(T []arr, int X)//constructor
    {
        head=new Node<>();
        tail=head;
        currentNode=head;
        for(int i=0;i< arr.length;i++) {
            if (i == 0) {
                head.setData(arr[i]);
                head.setNext(null);
                tail = head;
            } else {
                Node<T> newNode = new Node<>();
                newNode.setData(arr[i]);
                tail.setNext(newNode);
                tail = newNode;
            }
            currentSize++;
            //setToPos(2);
        }
    }//time complexity- O(n)
    public int size()
    {
        return currentSize;
    }//time complexity- O(1)
    public int push(T data)
    {
        Node<T>newNode=new Node<>();
        newNode.setData(data);
        Node<T>prevNode;
        Node<T>temp;
        currentSize++;
        if(currentNode==head)
        {
            newNode.setNext(head);
            head=newNode;
            currentNode=head;
        }
        else
        {
            prevNode=head;
            temp=head;
            while(temp!=null)
            {
                if(temp==currentNode)
                {
                    newNode.setNext(currentNode);
                    currentNode=newNode;
                    prevNode.setNext(newNode);
                }
                prevNode=temp;
                temp=temp.getNext();
            }
        }
        return -1;
    }//time complexity- O(n)
    public int pushBack(T data)//3//no effect of currentNode
    {
        if(head.getData()==null)
        {
            tail.setData(data);
            tail.setNext(null);
        }
        else
        {
            Node<T>newNode=new Node<>();
            tail.setNext(newNode);
            newNode.setData(data);
            newNode.setNext(null);
            tail=newNode;
        }
        currentSize++;
        return -1;
    }//time complexity- O(1)
    public int erase()
    {
        Node<T>temp;
        temp=head;
        int  ret;
        currentSize--;
        if(currentNode==head)
        {
            ret= (int) currentNode.getData();//kaj korsi
            head=currentNode.getNext();
            currentNode=currentNode.getNext();
            return ret;
        }
        else if(currentNode==tail)
        {
            prev();
            tail=currentNode;

        }
        else
        {
            Node<T>prevNode=new Node<>();
            while(temp!=null)
            {
                if(temp==currentNode)
                {
                    ret= (int) currentNode.getData();
                    currentNode=temp.getNext();
                    prevNode.setNext(temp.getNext());
                    return ret;
                }
                else
                {
                    prevNode=temp;
                    temp=temp.getNext();
                }
            }
        }
        return -1;
    }//time complexity- O(n)
    public int prev()
    {
        Node<T> temp;
        Node<T>prevNode=new Node<>();
        temp=head;

        while(temp!=null&& currentNode!=head)
        {
            if(temp==currentNode)
            {
                currentNode=prevNode;
                break;
            }
            prevNode=temp;
            temp=temp.getNext();
        }
        return -1;
    }//time complexity- O(n)
    public int next()
    {
        currentNode=currentNode.getNext();
        return -1;
    }//time complexity- O(1)
    public int setToBegin()//5
    {
        currentNode=head;
        return -1;
    }//time complexity- O(1)
    public int setToEnd()//6
    {
        currentNode=tail;
        return -1;
    }//time complexity- O(1)
    public int setToPos(int i)//10
    {
        int count=0;
        Node<T>temp;
        temp=head;
        if(i==0)currentNode=head;
        else {
            while (temp != null) {
                temp = temp.getNext();
                count++;
                if (count == i) {
                    currentNode = temp;
                    break;
                }
            }
        }
        return -1;
    }//time complexity- O(n)
    public int currPos()//9
    {
        int count =0;
        Node<T>temp;
        temp=head;
        while(temp!=currentNode)
        {
            count++;
            temp=temp.getNext();
        }
        return count;
    }//time complexity- O(n)
    public T getValue()//11
    {
        return currentNode.getData();
    }//time complexity- O(1)
    public int find(T data)//12
    {
        Node<T> temp;
        int count=0;
        temp=head;
        while(temp!=null)
        {
            if(data.equals(temp.getData()))
            {
                return count;
            }
            temp=temp.getNext();
            count++;
        }
        return -1;
    }//time complexity- O(n)
    public int clear()//13
    {
        head=tail=currentNode=null;
        return -1;
    }//time complexity- O(1)
    @Override
    public String toString()
    {
        Node<T> temp=new Node<>();
        temp = head;
        String str=new String();
        if (head == null) str+="<>";
        else {
            str += "< ";
            while (temp != null) {
                if (temp == currentNode)
                    str += "|";
                str += temp.getData() + " ";
                temp = temp.getNext();
            }
            str += ">";
        }
        return str;
    }//time complexity- O(n)

}
