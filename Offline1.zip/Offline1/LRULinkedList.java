class LRULinkedList<T>
{
    private int size=0;
    private MyLinkedList<T> keyList;
    private MyLinkedList<T> valueList;
    private int currentSize;
    LRULinkedList(int C)
    {
        keyList=new MyLinkedList<>(C);
        valueList=new MyLinkedList<>(C);
        currentSize=0;
        size=C;
    }
    public void put(T key,T value)
    {
        int ret=keyList.find(key);
        if(ret==-1)
        {
            keyList.pushBack(key);
            valueList.pushBack(value);
            currentSize++;
            if (currentSize > size) {
                keyList.setToBegin();
                keyList.erase();
                valueList.setToBegin();
                valueList.erase();
                currentSize--;
            }
        }
        else {
            keyList.setToPos(ret);
            valueList.setToPos(ret);
            keyList.erase();
            valueList.erase();
            keyList.pushBack(key);
            valueList.pushBack(value);

        }

    }//time complexity O(n)
    public int get(T key)
    {
        int ret;
        T retValue;
        ret=keyList.find(key);
        if(ret!=-1)
        {
            keyList.setToPos(ret);
            valueList.setToPos(ret);
            retValue=valueList.getValue();
            valueList.pushBack(retValue);
            keyList.pushBack(key);
            valueList.erase();
            keyList.erase();

            return (int)retValue;
        }//time complexity O(n)
        return ret;
    }
}

