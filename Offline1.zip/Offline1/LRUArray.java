public class LRUArray <T>{
        private int size=0;
        private MyArrayList<T> keyList;
        private MyArrayList<T>valueList;
        private int currentSize;
        LRUArray(int C)
        {
            keyList=new MyArrayList<>(C);
            valueList=new MyArrayList<>(C);
            currentSize=0;
            size=C;
        }
        public void put(T key,T value)
        {
            int ret=keyList.find(key);
            if(ret==-1)
            {
                keyList.pushBack(key);
                valueList.pushBack(value);
                currentSize++;
                if (currentSize > size) {
                    keyList.setToBegin();
                    keyList.erase();
                    valueList.setToBegin();
                    valueList.erase();
                    currentSize--;
                }
            }

            else {
                keyList.setToPos(ret);
                valueList.setToPos(ret);
                keyList.erase();
                valueList.erase();
                keyList.pushBack(key);
                valueList.pushBack(value);

            }

        }
        public int get(T key)
        {
            int ret;
            T retValue;
            ret=keyList.find(key);
            if(ret!=-1)
            {
                keyList.setToPos(ret);
                valueList.setToPos(ret);
                retValue=valueList.getValue();
                valueList.pushBack(retValue);
                keyList.pushBack(key);


                valueList.erase();
                keyList.erase();

                return (int)retValue;
            }
            return ret;
        }
    }
