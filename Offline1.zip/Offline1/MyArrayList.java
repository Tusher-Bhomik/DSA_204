public class MyArrayList<T> {
        private T[]arr;
        private int currentSize;
        private  int capacity;
        private int currentPosition;
        MyArrayList(int X)
        {
            capacity=X;
            this.arr=(T[])new Object[X];
        }//time complexity- O(1)
        MyArrayList(T []arr,int X)
        {
            currentPosition=0;
            this.currentSize= arr.length;
            this.capacity=X;
            this.arr=(T[]) new Object[capacity];
            for(int i=0;i<arr.length;i++){
                this.arr[i]=arr[i];
            }
            //setToPos(2);
        }//time complexity- O(n)
        public int size()//1
        {
            return currentSize;
        }//time complexity- O(1)
        public int push(T data)//2
        {
            if (currentSize == capacity) {
                extendArray();
            }

            for (int i = currentSize; i > currentPosition; i--) {
                arr[i] = arr[i - 1];
            }
            arr[currentPosition] = data;
            currentSize++;
            return -1;
        }//time complexity- O(n)
        public  int pushBack(T data)//3
        {
            if(currentSize==capacity)
            {
                extendArray();
            }
            arr[currentSize++]=data;
            //print();
            return -1;
        }//time complexity- O(1)
        public T erase()//4
        {
            T value=arr[currentPosition];
            for (int i=currentPosition;i<currentSize-1;i++)
            {
                arr[i]=arr[i+1];
            }
            currentSize--;
            if(currentPosition==currentSize)currentPosition--;
            if(currentSize<=capacity/2)
            {
                reduceArray();
            }
            return value;
        }//time complexity- O(n)
        public int setToBegin()//5
        {
            currentPosition=0;
            return -1;
        }//time complexity- O(1)
        public int setToEnd()//6
        {
            currentPosition=currentSize-1;
            return -1;
        }//time complexity- O(1)
        public int prev()//7
        {
            if (currentPosition != 0) {
                currentPosition--;
            }
            return -1;
        }//time complexity- O(1)
        public int next()//8
        {
            if (currentPosition < currentSize) {
                currentPosition++;
            }
            return -1;
        }//time complexity- O(1)
        public int currPos() {
            return currentPosition;
        }//time complexity- O(1)
        public int setToPos(int pos)//10
        {
            if(pos!=currentSize) currentPosition=pos;
            return -1;
        }//time complexity- O(1)
        public T getValue()//11
        {
            return arr[currentPosition];
        }//time complexity- O(1)
        public int find(T item)//12
        {
            for (int i = 0; i < currentSize; i++) {
                if (arr[i] .equals(item)) {
                    return i;
                }
            }
            return -1;
        }//time complexity- O(n)

        public int clear()//13
        {
            currentSize = currentPosition = 0;
            return -1;
        }//time complexity- O(1)
        private void extendArray()
        {
            T []extendedArray= (T[]) new Object[2*capacity];
            for(int i=0;i< arr.length;i++)
            {
                extendedArray[i]=arr[i];
            }
            this.arr=extendedArray;
        }//time complexity- O(n)
        private void reduceArray()
        {
            T []reducedArray= (T[]) new Object[capacity/2];
            capacity/=2;
            for(int i=0;i<currentSize;i++)
            {
                reducedArray[i]=arr[i];
            }
            this.arr=reducedArray;
        }//time complexity- O(n)
        public String toString()
        {
            String str=new String();
            str+="< ";
            for (int i=0;i<currentSize;i++)
            {
                if(i==currentPosition)str+="| ";
                str+=arr[i]+" ";
            }
            str+=">";
            return str;
        }//time complexity- O(n)
    }
