Here i categorized My class in segments
                i) Creating List
                ii) Implementing LRU cache using my own created Data Structure


     i)   file name : Node----> class (needed for Linked List Implementation)
     ii)  file name : MyArrayList----> (Here i wrote my necessary functions for implementing data structure using array)
     iii) file name : MyLinkedList----> ((Here i wrote my necessary functions for implementing data structure using array)
     iv)  file name : Main---->  (Identical Main function for implementing via Linked List or ArrayList)


     LRU Implementation
     i)   File name : LRUArray ---->( Here I implements LRU's all function using my own created ArrayList Data Structure )
     ii)  File name : LRULinkedList----> ( Here I implements LRU's all function using  my own created LinkedList Data Structure )
     iii) File name : LRUMain----> (Identical Main function for implementing LRU  via Linked List or ArrayList)