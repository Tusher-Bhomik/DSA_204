import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
//        PrintStream ps = new PrintStream("list_output.txt");
//        InputStream is = new FileInputStream("list_input.txt");
//
//        System.setIn(is);
//        System.setOut(ps);
        int K,X;
        Scanner scanner=new Scanner(System.in);
        K= scanner.nextInt();
        X= scanner.nextInt();
        Integer []arr=new Integer[K];
        for(int i=0;i<K;i++)
        {
            arr[i]=scanner.nextInt();
        }

        MyLinkedList<Integer> list1=new MyLinkedList<>(arr,X);
        int Q;
        Q=scanner.nextInt();
        int i=0;
        System.out.println(list1);
        while(i<Q)
        {
            int F,P,ret;
            F=scanner.nextInt();
            P=scanner.nextInt();
            switch (F) {
                case 1 -> {
                    ret=list1.size();
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 2 -> {
                    ret=list1.push(P);
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 3 -> {
                    ret=list1.pushBack(P);
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 4 -> {
                    ret=list1.erase();
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 5 -> {
                    ret=list1.setToBegin();
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 6 -> {
                    ret=list1.setToEnd();
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 7 -> {
                    ret=list1.prev();
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 8 -> {
                    ret=list1.next();
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 9 -> {
                    ret=list1.currPos();
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 10 -> {
                    ret=list1.setToPos(P);
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 11 -> {
                    ret=list1.getValue();
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 12 -> {
                    ret=list1.find(P);
                    System.out.println(list1);
                    System.out.println(ret);
                }
                case 13 -> {
                    ret=list1.clear();
                    System.out.println(list1);
                    System.out.println(ret);
                }
            }
            i++;
        }
    }
}
