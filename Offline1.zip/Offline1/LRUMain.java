import java.io.*;
import java.util.Scanner;

public class LRUMain {
    public static void main(String[] args) throws FileNotFoundException {

        PrintStream ps = new PrintStream(new File("lru_output.txt"));
        InputStream is = new FileInputStream("lru_input.txt");

        System.setIn(is);
        System.setOut(ps);
        int C,Q,i=0;
        Scanner scanner=new Scanner(System.in);
        C=scanner.nextInt();
        LRULinkedList<Integer>lruCache=new LRULinkedList<>(C);
        Q=scanner.nextInt();
        while(i<Q)
        {
            int p;
            p=scanner.nextInt();
            if(p==1)
            {
                int key;
                key=scanner.nextInt();
                System.out.println(lruCache.get(key));

            }
            else {
                int key,value;
                key=scanner.nextInt();
                value=scanner.nextInt();
                lruCache.put(key,value);
            }
            i++;
        }

    }
}
