import java.io.*;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
public class Offline {
    private int graph[][];

    Offline(int node,int graph[][])
    {
        this.node=node;
        this.graph=graph;
        visited=new boolean[node+1];
        Arrays.fill(visited, false);
    }
    private Queue<Integer>queue=new LinkedList<>();
    private int node;
    private boolean[]visited;

    void showMatrix(int [][]arr,int n)
    {
        for (int[] booleans : arr) {
            for (int aBoolean : booleans) {
                System.out.print(aBoolean + " ");
            }
            System.out.println();
        }
    }

    void BFS(int [][]arr,int n,int source)
    {
        boolean[] markVisited=new boolean[n+1];
        Queue<Integer>queue=new LinkedList<>();
        Queue<Integer>printQueue=new LinkedList<>();

        System.out.print(source+" ");
        markVisited[source]=true;
        queue.add(source);
        while(!queue.isEmpty())
        {
            int node=queue.remove();
            for(int j=1;j<n+1;j++)
            {
                if(arr[node][j]==1&& !markVisited[j])
                {
                    System.out.print(j+" ");
                    markVisited[j]=true;
                    queue.add(j);
                    printQueue.add(node);
                    printQueue.add(j);
                }
            }
        }
        System.out.println();
        System.out.println("Breadth first search followed this path:");
        while(!printQueue.isEmpty())
        {
            System.out.println(printQueue.remove()+"--->"+printQueue.remove());
        }

    }
    void DFS(int source)
    {
        System.out.print(source+" ");
        visited[source]=true;
        for(int i=1;i<node+1;i++)
        {
            if(graph[source][i]==1&&!visited[i])
            {
                queue.add(source);
                queue.add(i);
                DFS(i);

            }
        }
    }
    void startDFS(int n)
    {
        DFS(n);
        System.out.println();
        System.out.println("Depth first search followed this path:");
        while(!queue.isEmpty())
        {
            System.out.println(queue.remove()+"--->"+queue.remove());

        }
    }
    private static final String INPUT_FILE_NAME = "input.txt";
    public static void main(String[] args) throws IOException {
        PrintStream ps = new PrintStream("list_output.txt");
        System.setOut(ps);
        BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE_NAME));

        String line = br.readLine();//input first line
        String[] out = line.split(" ");

        int n,m,i=0;
        n= Integer.parseInt(out[0]);
        m= Integer.parseInt(out[1]);
        int[][] adjMat=new int[n+1][n+1];
        while(i<m)
        {
            String line2 = br.readLine();//input edge connections line
            String[] out2 = line2.split(" ");
            int x,y;
            x= Integer.parseInt(out2[0]);
            y= Integer.parseInt(out2[1]);
            adjMat[x][y]=1;
            //adjMat[y][x]=1;
            i++;
        }
        int source= Integer.parseInt(br.readLine());
        Offline offline=new Offline(n,adjMat);
        //offline.showMatrix(adjMat,n);

        offline.BFS(adjMat,n,source);
        System.out.println();
        offline.startDFS(source);

    }
}
