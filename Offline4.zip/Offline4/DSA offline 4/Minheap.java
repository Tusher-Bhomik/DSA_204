import static java.lang.Math.*;

public class Minheap {
    private int initSize;
    private int currSize;
    private int[] a;

    Minheap(int n) {
        initSize = n;
        a = new int[n];
    }

    public void insert(int data) {
        if (currSize == initSize) growHeap();
        int currPos = currSize;
        int parent, left, right;
            a[currSize++] = data;//last e insert
            while (currPos != 0) {
                parent = (currPos - 1) / 2;
                if (a[parent] > a[currPos]) {
                    //swap
                    int temp = a[currPos];
                    a[currPos] = a[parent];
                    a[parent] = temp;
                    currPos = parent;
                } else break;
            }
        }
    public int FindMin() {
        if (currSize == 0) {
            return -1;// -1 denotes heap is empty
        } else
            return a[0];
    }

    public boolean DecreaseKey(int prevKey, int newKey) {
        int currPos = 0;
        boolean found=false;
        for (int i = 0; i < currSize; i++) {
            if (a[i] == prevKey) {
                a[i] = newKey;
                currPos = i;
                found=true;
                break;
            }
        }
        if(found) {
            while (currPos != 0) {
                int parent = (currPos - 1) / 2;
                if (a[parent] > a[currPos]) {
                    //swap
                    int temp = a[currPos];
                    a[currPos] = a[parent];
                    a[parent] = temp;
                    currPos = parent;
                } else break;
            }
        }
        else {
            System.out.println( "Not Found previous  Key "+prevKey);
        }
        return found;
    }

    public int ExtractMin() {

        if (currSize == 0) {
            return -1;
        }
        if (currSize == 1) {
            currSize--;
            return a[0];
        } else {
            int ret = a[0];
            a[0] = a[currSize - 1];
            currSize--;

            int currPos = 0;
            int left = 1;
            int right = 2;
            while ((left<currSize&&a[currPos]>a[left])||(right<currSize&&a[currPos] > a[right])) {
                if (a[left] <= a[right]) {
                    int temp = a[left];
                    a[left] = a[currPos];
                    a[currPos] = temp;
                    currPos = left;
                } else {
                    int temp = a[right];
                    a[right] = a[currPos];
                    a[currPos] = temp;
                    currPos = right;
                }
                left = 2 * currPos + 1;
                right = 2 * currPos + 2;
            }
            return ret;
        }
    }

    void print() {
        System.out.println("Printing Binary Heap.......................");
        int N = (int) (ceil(log(currSize) / log(2)));
        int k = 0;
        boolean ind = true;
        for (int i = 0; i <= N; i++) {
            System.out.print("Level " + i + ":");
            for (int j = 0; j < pow(2, i); j++) {
                System.out.print(a[k] + " ");
                k++;
                if (k == currSize) {
                    ind = false;
                    break;
                }
            }
            System.out.println();
            if (!ind) break;
        }
        System.out.println(".........................................");
    }

    private void growHeap()
    {
        initSize*=2;
        int[] x =new int[initSize];
        for(int i=0;i<currSize;i++)
        {
            x[i]=a[i];
        }
        a=x;
    }
}
