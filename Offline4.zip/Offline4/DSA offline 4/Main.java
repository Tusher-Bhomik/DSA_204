import java.io.*;

public class Main {
    private static final String INPUT_FILE_NAME = "input.txt";

    public static void main(String[] args) throws IOException {
        PrintStream ps = new PrintStream("list_output.txt");
        System.setOut(ps);
        BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE_NAME));
        Minheap minheap = new Minheap(3);
        while (true) {
            String line = br.readLine();
            if (line == null) break;
            String[] out = line.split(" ");
            switch (out[0]) {
                case "INS" -> {
                    minheap.insert(Integer.parseInt(out[1]));
                    System.out.println("Inserted "+Integer.parseInt(out[1]));
                }
                case "PRI" -> {
                    minheap.print();
                }
                case "DEC" -> {
                    if (Integer.parseInt(out[1]) < Integer.parseInt(out[2]))
                        System.out.println("New key must be smaller than previous key");
                    else {
                       boolean f=minheap.DecreaseKey(Integer.parseInt(out[1]), Integer.parseInt(out[2]));
                       if(f)
                        System.out.println(Integer.parseInt(out[1]) + " decreased to " + Integer.parseInt(out[2]));
                    }
                }
                case "FIN" -> {
                    if(minheap.FindMin()!=-1)
                    System.out.println("FindMin returned "+minheap.FindMin());
                    else
                    {
                        System.out.println("Heap is Empty");
                    }
                }
                case "EXT" -> {
                    int f=minheap.ExtractMin();
                    if(f!=-1)
                        System.out.println("ExtractMin returned "+f);
                    else {
                        System.out.println("Heap is Empty");
                    }
                }

            }
        }
    }
}